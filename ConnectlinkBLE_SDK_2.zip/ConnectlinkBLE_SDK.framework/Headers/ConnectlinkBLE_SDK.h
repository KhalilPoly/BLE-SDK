//
//  ConnectlinkBLE_SDK.h
//  ConnectlinkBLE-SDK
//
//  Created by Khalil Loghlam on 2018-11-15.
//  Copyright © 2018 Fortin Electronic Systems. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ConnectlinkBLE_SDK.
FOUNDATION_EXPORT double ConnectlinkBLE_SDKVersionNumber;

//! Project version string for ConnectlinkBLE_SDK.
FOUNDATION_EXPORT const unsigned char ConnectlinkBLE_SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConnectlinkBLE_SDK/PublicHeader.h>


